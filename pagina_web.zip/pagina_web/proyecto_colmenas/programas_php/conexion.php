<?php

$host = "sql110.infinityfree.com";   // Host MySQL
$user = "if0_40451815";              // Usuario MySQL
$pw = "Sosourcandy123";     // La misma contraseña de tu cuenta InfinityFree
$db = "if0_40451815_proy_int";       // Nombre de tu base de datos

?>
