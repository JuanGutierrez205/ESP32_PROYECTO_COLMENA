                                                       
<?php

// PROGRAMA DE FINALIZACION DE SESION
                   
$cadena="20220603";
$cadena_codif = md5($cadena);
echo "cadena codif es...".$cadena_codif;

?>
