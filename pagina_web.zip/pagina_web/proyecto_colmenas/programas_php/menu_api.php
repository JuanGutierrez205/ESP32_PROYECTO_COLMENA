<?php
echo '


  	     <tr>
              <td colspan=2 width="25%" height="20%" align="left" 				
                 bgcolor="#FFFFFF" class="_espacio_celdas" 					
                 style="color: #FFFFFF; 
		         font-weight: bold">
             	 <a href="gestion_usuarios.php"><img src="img/gestion_de_usuario.jpg" border=0></a> 
				 <a href="consulta_por_colmena.php"><img src="img/Monitoreo_apiario.jpg" border=0></a>
				 <a href="gestion_colmenas.php"><img src="img/Gestion_de_colmena.jpg" border=0></a>
				 <a href="generar_grafico.php"><img src="img/Graficass.png" border=0></a>
				 <a href="mapa.php"><img src="img/mapa.png" border=0></a>

		         <hr>
		       </td>
	    </tr>
';

                 //<img src="img/menu_admin/eliminar_devolucion_peq.jpg" border=0>
			           
?>